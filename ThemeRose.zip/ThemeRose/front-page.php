<?php get_header();?>
<div class="container">
    <?php while(have_posts()):the_post();?>
    <div class="title">
        <?php the_title();?>
    </div>
    <div class="header_cont">
        <?php the_content();?>
    </div>
</div>

<?php endwhile;?>
<?php get_footer();?>